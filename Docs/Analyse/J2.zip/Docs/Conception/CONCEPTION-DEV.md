# Conception technique DEV (J2)

> Équipe 7 — version 1.0 du 15/10/2026. Choix de travail à valider avec le pôle DEV. Contrat avec DATA : `CONTRAT-INTERFACE.md`. Base : `MODELE-DONNEES.md`.

## 1. Architecture

**Principe : on calcule à l'avance, on lit au moment de la visite.** Un script de pré-calcul interroge Open-Meteo, calcule les indicateurs et remplit `Fact_Indicateur`. Le site ne lit que la base : il ne dépend pas du quota de l'API et répond vite.

```mermaid
flowchart LR
    API[Open-Meteo Climate API] -->|flux A : séries| CLI[OpenMeteoClient<br/>cache fichier]
    CLI --> CALC[indicateurs.php<br/>module DATA]
    CALC -->|flux C : UPSERT| DB[(SQLite<br/>schéma en étoile)]
    DB --> SITE[Pages PHP<br/>PDO, requêtes préparées]
    SITE --> NAV[Navigateur]
    PRE[precalcul.php<br/>lancé à la main en SSH] --> CLI
```

| Élément | Choix | Pourquoi |
|---|---|---|
| Langage | PHP 8.4, PDO | Disponible sur AlwaysData (vérifié le 13/10), clé API gardée côté serveur. |
| Base | **SQLite**, un fichier | Plan gratuit de 100 Mo, pas de serveur à administrer, driver PDO présent. Le schéma en étoile est standard et passerait à MySQL sans changer les tables. Limite : un seul écrivain à la fois, sans gravité ici (écriture par un script, lecture par le site). |
| Où est la base | Hors du dossier public (`/data/climat.sqlite`, à côté de `www/`) | Un fichier dans `www/` serait téléchargeable. |
| Clé API | Variable d'environnement `OPENMETEO_API_KEY`, jamais dans git | `.env.example` documente le nom. |
| Appel de l'API | Côté serveur uniquement | Le navigateur ne voit jamais la clé. |
| Pré-calcul | Script PHP en ligne de commande, relançable | Pas d'appel API pendant la visite ; relance sans doublon (UPSERT). |
| Front | HTML/CSS + un peu de JS, pas de framework | Équipe réduite, une seule personne côté DEV pur. |

Volume : 16 communes × 2 horizons × modèles retenus = 64 à 96 séries de 30 ans, chacune servant à 10 cultures. Soit 640 à 960 lignes de faits, quelques dizaines de Ko.

Arborescence :
```
climat-cultures/
├── DATA/creation_bdd.sql, requetes_etoile.sql, tests/
├── Docs/Conception/        ce dossier
├── scripts/
│   ├── lib/                OpenMeteoClient.php, indicateurs.php, precalcul.php
│   ├── init_db.php, precalcul.php, test_*.php
│   └── page-statique/      seul dossier servi par AlwaysData (www/)
└── .env.example
```
⚠ À terme, seules les pages du site doivent être dans le dossier servi ; `scripts/lib` et la base restent au-dessus.

## 2. Conception du client API

| Sujet | Décision |
|---|---|
| Endpoint | `https://customer-climate-api.open-meteo.com/v1/climate` avec `apikey` (clé de la promotion). Sans clé : `climate-api.open-meteo.com`, quota par IP. |
| Paramètres | `latitude`, `longitude` (de `Dim_Commune`), `models` (un seul par appel), `start_date`, `end_date`, `daily=temperature_2m_max,temperature_2m_min,temperature_2m_mean,precipitation_sum`. |
| Découpage | Un appel = une commune, un modèle, un horizon complet (30 ans). Le coût d'un appel croît avec la durée : on ne boucle pas année par année. |
| Données | Période limitée à 1950-2049. Les valeurs sont brutes (biais du modèle) : on n'exploite que la tendance, jamais une valeur absolue comme prévision. |
| Cache | Fichier JSON par couple (latitude, longitude, modèle, période), hors dossier public, durée 30 jours. La clé API n'est jamais écrite dans le cache. |
| Délais | 5 s de connexion, 20 s au total. |
| Nouvelles tentatives | 2 (après 1 s puis 3 s) sur erreur réseau ou HTTP 5xx. Aucune sur 429 ni 4xx. |
| Quota | Sur 429 le pré-calcul s'arrête proprement, et se relance le lendemain : le cache évite de refaire les appels déjà réussis. |
| Validation | `daily` présent, quatre variables de même longueur que `time`. Sinon `ReponseInvalide`. |
| Données vides | Toutes les valeurs nulles : `DonneesVides` (cas observé avec EC_Earth3P_HR). Le couple est ignoré et listé dans le compte rendu. |
| Valeurs manquantes isolées | Conservées `null`, transmises à DATA. |
| Sécurité | Les messages d'erreur ne contiennent jamais l'URL (qui contient la clé). |

Code : `scripts/lib/OpenMeteoClient.php`. Tests : `scripts/test_client.php` (réponses simulées, aucun appel réel).

## 3. Plan de test

| Niveau | Quoi | Comment | État |
|---|---|---|---|
| Base | contraintes (UNIQUE, FK, CHECK), jointure en étoile, suppression RGPD | `php scripts/test_bdd.php` | 17 OK |
| Calcul | 4 cas imposés (année sans gel, canicule, valeur manquante, seuil exact) + ET0 + seuil absent + moyenne d'horizon | `php scripts/test_indicateurs.php`, attendus dans `DATA/tests/resultats_attendus.csv` | 23 OK |
| Client API | réponse nominale, cache, nulls, 429, 4xx, 5xx avec reprise, JSON invalide, vide, clé absente des messages | `php scripts/test_client.php` | 16 OK |
| Intégration | API simulée → calcul → base ; relance sans doublon ; modèle vide ignoré ; quota | `php scripts/test_precalcul.php` | 8 OK |
| Réel | un appel réel sur Paris 2049 (déjà fait le 10/10) puis un pré-calcul réel sur 1 commune | `php scripts/precalcul.php --commune=75056 --modele=MRI_AGCM3_2_S` | **à faire** avec la clé |
| Déploiement | la page affiche une ligne lue en base sur AlwaysData | ouvrir la page de test | **à faire** |
| Interface (J3) | affichage des 4 indicateurs, états vide / erreur / chargement | parcours des maquettes | J3 |

Tout lancer : `sh scripts/run_tests.sh` (doit afficher 0 KO partout).

## 4. Base partagée sur AlwaysData

1. Sur le serveur, dans le dépôt cloné : `git pull` sur la branche voulue.
2. Créer la base **hors du dossier public** : `php scripts/init_db.php ~/data/climat.sqlite`. Le script efface et recrée les tables : ne jamais le relancer sur une base déjà remplie.
3. Exporter la clé pour la session SSH : `export OPENMETEO_API_KEY=...` (ne pas l'écrire dans un fichier du dépôt).
4. Lancer d'abord un test réduit : `php scripts/precalcul.php --base=$HOME/data/climat.sqlite --commune=75056 --modele=MRI_AGCM3_2_S`, puis le pré-calcul complet.
5. Vérifier : `php -r '...'` ou une page de test qui affiche `SELECT COUNT(*) FROM Fact_Indicateur`.
6. Sauvegarde avant toute modification : `cp ~/data/climat.sqlite ~/data/climat-$(date +%F).sqlite`.

## 5. Document de conception : écrans et données

Référence visuelle : maquettes Figma « Climix » (6 écrans mobile 390 px, 9 écrans bureau 1280 px), exportées dans `Docs/Maquettes/`.

| Écran (maquettes) | Données lues | Requête |
|---|---|---|
| Accueil | rien | |
| Sélection, suggestions | `Dim_Commune` (nom, département), `Dim_Culture` (nom), horizons de `Dim_Temps` | listes simples |
| Sélection, commune inconnue | aucune correspondance dans `Dim_Commune` | recherche sur `nom` ; liste fermée de 16 communes |
| Résultat | les 2 horizons d'un couple commune / culture / modèle, et leur différence (« environ 12 jours de gel en moins ») | Q1, différence calculée en PHP ou Q2 |
| Fourchette entre modèles (« bientôt ») | un fait par modèle | Q4, quand l'équipe décide de l'afficher |
| Méthode & sources | texte fixe | |
| Chargement | attente de la lecture en base | |
| Service indisponible | base illisible, ou erreur d'écriture du pré-calcul | exception PDO |
| Aucune donnée | aucun fait pour ce couple (pré-calcul pas encore fait ou modèle ignoré) | Q1 sans résultat ; Q6 pour la liste des trous |
| Paramètres invalides | commune, culture ou horizon absent des dimensions | vérification avant la requête |

Règles d'affichage tirées des maquettes et de la base :
- Un indicateur `null` s'affiche « non disponible », jamais 0.
- Bandeau « données incomplètes » (ajouté aux maquettes le 17/10) : affiché seulement si `nb_jours_manquants` > 0.
- L'écran Résultat montre les 4 indicateurs, chacun dans une carte avec graphique à 2 barres (période de référence / horizon 2050) et son tableau : jours de gel, degrés-jours (GDD), jours de stress thermique, déficit en eau. Le bilan hydrique est présenté comme un déficit (valeur positive) ; si le bilan est excédentaire, l'écran devra le dire autrement. Valeurs de démonstration fictives.
- Verdict : `favorable` = « Culture adaptée », `a_surveiller` = « Culture encore viable, à surveiller », `defavorable` = « Culture en difficulté ». Une carte « Les trois verdicts possibles » les explique. La règle de calcul du verdict reste à définir (DATA 2).
- « Aucune donnée » : le bouton renvoie à la recherche (« Modifier ma recherche ») : la base n'a que deux horizons.
- L'étiquette « Situation actuelle » est remplacée partout par « Période de référence » (1990-2019).
- Écarts restants maquettes / base : voir `MODELE-DONNEES.md` §5.
