#!/bin/sh
# Lance tous les tests. Usage : sh scripts/run_tests.sh
cd "$(dirname "$0")/.." || exit 1
status=0
for t in test_bdd test_indicateurs test_client test_precalcul; do
  echo "== $t"
  out=$(php "scripts/$t.php") || status=1
  echo "$out" | grep -E ' KO|OK, [0-9]+ KO'
done
[ $status -eq 0 ] && echo "TOUS LES TESTS PASSENT" || echo "ÉCHEC"
exit $status
